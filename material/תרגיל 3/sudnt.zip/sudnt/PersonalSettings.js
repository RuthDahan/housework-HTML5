//document.body.style.backgroundColor = localStorage.getItem('background')
if (sessionStorage.getItem("background-color") != null)
    document.body.style.backgroundColor = sessionStorage.getItem("background-color");
else
    document.body.style.backgroundColor = localStorage.getItem("background-color");

if (sessionStorage.getItem("font-color") != null)
    document.body.style.color = sessionStorage.getItem("font-color");
else
    document.body.style.color = localStorage.getItem("font-color");

if (sessionStorage.getItem("font-type") != null)
    document.body.style.fontFamily = sessionStorage.getItem("font-type");
else
    document.body.style.fontFamily = localStorage.getItem("font-type");

if (sessionStorage.getItem("font-size") != null)
    document.body.style.fontSize = sessionStorage.getItem("font-size");
else
    document.body.style.fontSize = localStorage.getItem("font-size");

// function localB(key, value) {
//     localStorage.setItem(key, value);
//     document.body.style.backgroundColor = localStorage.getItem(key)

//     sessionStorage.clear(key)
//     // document.getElementById(key).value = value
// }
// function sessionB(key, value) {
//     sessionStorage.setItem(key, value)
//     document.body.style.backgroundColor = sessionStorage.getItem(key)
//     localStorage.clear(key)
//     // document.getElementById(key).value = value
// }

// function localF(key, value) {
//     localStorage.setItem(key, value)
//     document.body.style.color = localStorage.getItem(key)
//     sessionStorage.clear(key)
//     // document.getElementById(key).value = value
// }
// function sessionF(key, value) {
//     sessionStorage.setItem(key, value)
//     document.body.style.color = sessionStorage.getItem(key)
//     localStorage.clear(key)
//     // document.getElementById(key).value = value
// }

// function localSe(key, value) {
//     localStorage.setItem(key, value)
//     document.body.style.fontFamily = localStorage.getItem(key)
//     sessionStorage.clear(key)
//     // document.getElementById(key).value = value
// }
// function sessionSe(key, value) {
//     sessionStorage.setItem(key, value)
//     document.body.style.fontFamily = sessionStorage.getItem(key)
//     localStorage.clear(key)
//     // document.getElementById(key).value = value
// }

// function localSi(key, value) {
//     localStorage.setItem(key, value)
//     document.body.style.fontSize = localStorage.getItem(key)
//     sessionStorage.clear(key)
//     // document.getElementById(key).value = value
// }
// function sessionSi(key, value) {
//     sessionStorage.setItem(key, value)
//     document.body.style.fontSize = sessionStorage.getItem(key)
//     localStorage.clear(key)
//     // document.getElementById(key).value = value
// }


function local(key) {
    localStorage.setItem(key,document.getElementById(key).value);
    //localStorage.setItem(key, value)
    // document.body.style.fontSize = localStorage.getItem(key)
    //sessionStorage.clear(key)
    // document.getElementById(key).value = value
}
function session(key) {
    sessionStorage.setItem(key,document.getElementById(key).value);
    //sessionStorage.setItem(key, value)
    // document.body.style.fontSize = sessionStorage.getItem(key)
    //localStorage.clear(key)
    // document.getElementById(key).value = value
}

function ChangeDesign() {
    if (sessionStorage.getItem("background-color") != null) {
        document.body.style.backgroundColor = sessionStorage.getItem('background-color')
    } else {
        if (localStorage.getItem("background-color") != null) {
            document.body.style.backgroundColor = localStorage.getItem('background-color')
        }
    }
    if (sessionStorage.getItem("font-color") != null) {
        document.body.style.color = sessionStorage.getItem('font-color')
    } else {
        if (localStorage.getItem("font-color") != null) {
            document.body.style.color = localStorage.getItem('font-color')
        }
    }
    if (sessionStorage.getItem("font-type") != null) {
        document.body.style.fontFamily=sessionStorage.getItem('font-type')
    } else {
        if (localStorage.getItem("font-type") != null) {
            document.body.style.fontFamily=localStorage.getItem('font-type')
        }
    }
    if (sessionStorage.getItem("font-size") != null) {
        document.body.style.fontSize=sessionStorage.getItem('font-size')
    } else {
        if (localStorage.getItem("font-size") != null) {
            document.body.style.fontSize=sessionStorage.getItem('font-size')
        }
    }
}





