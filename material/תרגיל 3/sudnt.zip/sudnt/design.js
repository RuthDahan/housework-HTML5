
Update();
function Local(name) {
    localStorage.setItem(name, document.getElementById(name).value);
    sessionStorage.setItem(name)=null;
}
function Session(name) {
    sessionStorage.setItem(name, document.getElementById(name).value);
    localStorage.setItem(name)=null;
}

function Update() {
    if (sessionStorage.getItem("background") != null) {
        document.body.style.backgroundColor = sessionStorage.getItem("background");
    }
    else {
        document.body.style.backgroundColor = localStorage.getItem("background");
    }
    if (sessionStorage.getItem("fontColor") != null) {
        document.body.style.color = sessionStorage.getItem("fontColor");
    }
    else {
        document.body.style.color = localStorage.getItem("fontColor");
    }
    if (sessionStorage.getItem("font-Size") != null) {
        document.body.style.fontSize = sessionStorage.getItem("font-Size");
    }
    else{
        document.body.style.fontSize = localStorage.getItem("font-Size");
    }
    if (sessionStorage.getItem("font-Type") != null) {
        document.body.style.fontFamily = sessionStorage.getItem("font-Type");
    }
    else {
        document.body.style.fontFamily = localStorage.getItem("font-Type");
    }

}
